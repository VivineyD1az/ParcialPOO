import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Frminicio extends JFrame implements ActionListener {
    static FrmListar ventanaListar;
    static FrmRegistrar ventanaRegistrar;
    static JLabel lblLogo;
    static JButton btnRegistrar;
    static JButton btnListar;
    static JButton btnsalir;
    static Frminicio ventana;
    static JLabel lblNumeroUno;
    static ArrayList<Estudiantes> estudiantesregistrados = new ArrayList<>();

    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(btnRegistrar)) {
            ventanaRegistrar.setVisible(true);
            this.setVisible(false);
        }

        if (e.getSource().equals(btnListar)) {
            ventanaListar.setVisible(true);
            this.setVisible(false);
        }

        if (e.getSource().equals(btnsalir)) {
            this.dispose();
        }

    }

    public Frminicio() {
        ventanaListar = new FrmListar();
        ventanaRegistrar = new FrmRegistrar(ventanaListar);
        this.setLayout(null);


        btnRegistrar = new JButton("REGISTRAR");
        btnListar = new JButton("LISTAR");
        btnsalir = new JButton("SALIR");


        btnRegistrar.addActionListener(this);
        btnListar.addActionListener(this);
        btnsalir.addActionListener(this);


        btnRegistrar.setBounds(145, 70, 150, 30);
        btnListar.setBounds(145, 120, 150, 30);
        btnsalir.setBounds(145, 170, 150, 30);


        lblLogo = new JLabel();
        lblLogo.setBounds(100, 80, 210, 200);
        lblNumeroUno = new JLabel("MENU DE OPCIONES");
        lblNumeroUno.setBounds(160, 20, 200, 30);


        getContentPane().add(lblNumeroUno);
        getContentPane().add(lblLogo);
        getContentPane().add(btnRegistrar);
        getContentPane().add(btnListar);
        getContentPane().add(btnsalir);


        getContentPane().setBackground(new Color(250, 250, 250));
        setSize(450, 350);
        setTitle("VENTANA PRINCIPAL");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocation(300, 200);
    }

    public static void main(String[] args) {
        ventana = new Frminicio();
        ventana.setVisible(true);
    }
}