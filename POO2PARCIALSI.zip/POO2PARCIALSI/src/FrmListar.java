import java.awt.Color;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class FrmListar extends JFrame implements ActionListener {
    static JLabel lbltituloXD;
    static JButton btnRegresar;
    static ImageIcon imgRegresar;
    static JTable tabla;
    static DefaultTableModel model;
    static JScrollPane scrollpane;

    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(btnRegresar)) {
            InterfazLogin.ventanaMensaje.setVisible(true);
            this.setVisible(false);
        }

    }

    public FrmListar() {
        imgRegresar = new ImageIcon(".\\img\\back.png");
        btnRegresar = new JButton("Regresar", imgRegresar);
        btnRegresar.setBounds(50, 250, 110, 30);
        btnRegresar.addActionListener(this);
        lbltituloXD = new JLabel("Tabla Estudiantes");
        lbltituloXD.setBounds(40, 10, 200, 30);
        model = new DefaultTableModel();
        tabla = new JTable(model);
        model.addColumn("Usuario");
        model.addColumn("Contraseña");
        scrollpane = new JScrollPane(tabla);
        scrollpane.setLocation(40, 40);
        scrollpane.setSize(350, 200);
        this.add(lbltituloXD);
        this.add(btnRegresar);
        this.add(scrollpane, "Center");
        Color c = new Color(173, 216, 230);
        this.getContentPane().setBackground(c);
        this.setLayout((LayoutManager)null);
        this.setSize(450, 350);
        this.setTitle("LISTADO DE EESTUDIANTES");
        this.setDefaultCloseOperation(3);
        this.setLocation(300, 200);
    }

    public void agregarEstudiantes(ArrayList<Estudiantes> propietarios) {
        model.setRowCount(0);
        Iterator var2 = propietarios.iterator();

        while(var2.hasNext()) {
            Estudiantes estudiantes= (Estudiantes) var2.next();
            Object[] fila = new Object[]{estudiantes.getUsuario(), estudiantes.getContraseña()};
            model.addRow(fila);

        }

    }
}