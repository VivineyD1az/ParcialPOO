import javax.swing.*;
import java.awt.event.*;
import javax.swing.JOptionPane;

public class InterfazLogin extends JFrame implements ActionListener {
    public JTextField estudianteField;
    public JPasswordField contraseñaField;
    private JButton botonLogin;
    public static Frminicio ventanaMensaje;


    public InterfazLogin() {
        setTitle("Inicio de Sesión ");
        setSize(800, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(null);


        JLabel usuarioLabel = new JLabel("Usuario:");
        usuarioLabel.setBounds(50, 50, 100, 30);
        panelPrincipal.add(usuarioLabel);

        estudianteField = new JTextField();
        estudianteField.setBounds(50, 90, 200, 30);
        panelPrincipal.add(estudianteField);

        JLabel contraseñaLabel = new JLabel("Contraseña:");
        contraseñaLabel.setBounds(50, 130, 100, 30);
        panelPrincipal.add(contraseñaLabel);

        contraseñaField = new JPasswordField();
        contraseñaField.setBounds(50, 170, 200, 30);
        panelPrincipal.add(contraseñaField);


        botonLogin = new JButton("Iniciar Sesión");
        botonLogin.addActionListener(this);
        botonLogin.setBounds(50, 210, 150, 30);
        panelPrincipal.add(botonLogin);


        JLabel imagenLabel = new JLabel();
        ImageIcon imagenIcono = new ImageIcon("foto1.jpeg");
        imagenLabel.setIcon(imagenIcono);
        imagenLabel.setBounds(300, 0, 500, 400);
        panelPrincipal.add(imagenLabel);

        add(panelPrincipal);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(botonLogin)) {
            String usuario = estudianteField.getText();
            String contraseña = new String(contraseñaField.getPassword());

            if (Estudiantes.validarUsuario(usuario, contraseña)) {
                ventanaMensaje = new Frminicio();
                ventanaMensaje.setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos", "Error de inicio de sesión", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    public static void main(String[] args) {
        InterfazLogin interfaz = new InterfazLogin();
        interfaz.setVisible(true);

    }
}