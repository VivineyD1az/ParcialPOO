import javax.swing.JOptionPane;
import java.io.*;

public class Estudiantes {
    String usuario;
    double contraseña;

    public Estudiantes(String usuario, double contraseña) {
        this.usuario = usuario;
        this.contraseña = contraseña;
    }

    public String getUsuario() {
        return this.usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public double getContraseña() {
        return contraseña;
    }

    public void setContraseña(double contraseña) {
        this.contraseña = contraseña;
    }

    static boolean validarUsuario(String usuario, String password){
        boolean bnd=false;
        String usuarios = leertxt.leer("estudianteslog1.txt");
        String[] usuarioclave= usuarios.split(";");
        String[] us;

        for (int i = 0; i < usuarioclave.length; i++) {
            us=usuarioclave[i].split(",");
            if (us[0].equals(usuario) && us[1].equals(password)){
                bnd = true;
            }
        }
        return bnd;
    }
}