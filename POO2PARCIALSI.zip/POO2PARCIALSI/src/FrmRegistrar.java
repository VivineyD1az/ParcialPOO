import java.awt.Color;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class FrmRegistrar extends JFrame implements ActionListener {
    FrmListar ventanaListar;
    static JButton btnRegresar;
    static JButton btnRegistrar;
    protected JTextField campo1;
    protected JTextField campo2;
    static JLabel lblNuM4;
    protected ArrayList<Estudiantes> estudiantesregistro;

    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(btnRegresar)) {
            InterfazLogin.ventanaMensaje.setVisible(true);
            this.setVisible(false);
        }

        if (e.getSource().equals(btnRegistrar)) {
            String usuario = this.campo1.getText();
            int contraseña = Integer.parseInt(this.campo2.getText());
            Estudiantes nuevoEstudiante= new Estudiantes(usuario,contraseña);
            this.estudiantesregistro.add(nuevoEstudiante);
            this.campo1.setText(" ");
            this.campo2.setText(" ");
        }

    }

    public FrmRegistrar(FrmListar ventanaListar) {
        this.ventanaListar = ventanaListar;
        btnRegresar = new JButton("Regresar");
        btnRegresar.setBounds(100, 250, 110, 30);
        btnRegresar.addActionListener(this);
        this.estudiantesregistro = new ArrayList();
        this.Registro();
        this.add(btnRegresar);
    }

    protected void Registro() {
        this.setLayout((LayoutManager)null);
        lblNuM4 = new JLabel(" REGISTRO DE Estudiantes");
        lblNuM4.setBounds(30, 20, 200, 30);
        this.add(lblNuM4);
        JLabel etiqueta1 = new JLabel("Elija el usuario: ");
        etiqueta1.setBounds(50, 40, 200, 30);
        this.add(etiqueta1);
        this.campo1 = new JTextField();
        this.campo1.setBounds(250, 40, 150, 30);
        this.add(this.campo1);
        JLabel etiqueta2 = new JLabel("Elija la contraseña");
        etiqueta2.setBounds(50, 80, 200, 30);
        this.add(etiqueta2);
        this.campo2 = new JTextField();
        this.campo2.setBounds(250, 80, 150, 30);
        this.add(this.campo2);
        JButton botonAgregar = new JButton("Registrar Datos");
        botonAgregar.setBounds(350, 250, 150, 30);
        botonAgregar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String usuario =FrmRegistrar.this.campo1.getText();
                int contraseña =  Integer.parseInt(FrmRegistrar.this.campo2.getText());;
                Estudiantes nuevoEstudiante= new Estudiantes(usuario,contraseña);
                FrmRegistrar.this.estudiantesregistro.add(nuevoEstudiante);
                Frminicio.estudiantesregistrados.add(nuevoEstudiante);
                FrmRegistrar.this.ventanaListar.agregarEstudiantes(FrmRegistrar.this.estudiantesregistro);
                FrmRegistrar.this.campo1.setText("");
                FrmRegistrar.this.campo2.setText("");
            }
        });
        this.add(botonAgregar);
        Color c = new Color(173, 216, 230);
        this.getContentPane().setBackground(c);
        this.setLayout((LayoutManager)null);
        this.setSize(550, 350);
        this.setTitle("Registrar Propietarios");
        this.setDefaultCloseOperation(3);
        this.setLocation(300,200);
    }
}